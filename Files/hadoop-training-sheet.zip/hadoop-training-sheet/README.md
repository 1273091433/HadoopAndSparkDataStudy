#Hadoop Training Sheet


---

###1. 操作系统

- Linux操作系统（检查操作系统版本号）

- Linux操作系统概述

- 安装Linux操作系统
	> CentOS、Ubuntu

- Linux Shell相关工具的使用
	> Xshell、Xftp

- Linux图形界面、字符界面

- Linux基本命令
	- 查看主机名：hostname
	 
	- 硬件配置：df、free、ethtool
	 
	- 文件/文件夹操作：cd、mkdir、rm、cp、mv、touch、du、lsof
	
	- 查看文本：cat、less、tail、vim、vi
	
	- 查找类：grep、find
	
	- 压缩解压缩：tar、gzip、zip、unzip

	- 软件安装类：rpm、yum、apt-get
	
	- 帮助类：man
	
	- 时间类：date
	
	- IO类：lostat
	
	- 权限类：sudo、chown、chmod、chgrp
	
	- 端口连接类：netstat、ping、telnet
	
	- 启停服务类：etc/init.d/mysqld [start|stop|restart]
	
	- 网页类：elinks http://192.168.1.210:60010
	
	- 挂载类：mount、umount

- 用户、组群和权限管理
	
- 文件系统管理

- 软件包管理与系统备份

- Linux网络配置

- Linux基本服务配置
	> DNS服务、DHCP服务、HTTP服务、FTP服务、SMTP服务、POP3服务
- Linux Shell命令
	- 文件及文本常用命令：tar、find、cut、wc、split、grep、head、tail、sed、awk

	- 系统运行状况命令：top、watch、free、mpstat、vmstat、lostat、pidstat、df、du

	- 系统运行进程命令：ps、nice、renice、lsof、pgrep、pkill

	- 追踪命令：strace

	- 排序命令：sort

	- 删除重复行：uniq

	- 正则表达式

- Linux Shell脚本编写

	- 定时备份系统日志

	- 自动监控其它主机硬盘及内存使用状况	

	- 自动化安装JDK、Tomcat

###2. 数据库

- 关系型数据库原理

- 在Linux上安装Mysql、SQL-Server、DB2、Oracle数据库

- DDL、DML、DCL语法

	> Mysql、SQL-Server、Oracle、DB2

- SQL基础
	- 基本语句：insert、select、where、update、delete、join、group by、having、desc、asc、limit、isnull、等

	- 函数：日期函数、嵌套函数、字符串函数、数字函数、聚集函数

- SQL高级
	- PL/SQL、if、case、loop、while、for、游标、视图、索引、存储过程、事务、SQL编程

- 数据库管理
	- 容量规划

	- 安全

	- 性能

	- 对象

	- 存储管理

	- 变化管理

	- 任务调度

	- 网络管理

	- 故障排查

	- 管理工具
		- Mysql：Workbench、Navicat
		- SQL-Server：SSMSE
		- Oracle：OEM、PL/SQL developer、Toad
		- DB2：DB2top、Toad for db2

- 备份与恢复
	- 文件：参数文件、控制文件、数据文件、转储文件、重做日志

	- 备份：冷备份、热备份

	- 还原和恢复：备份控制文件、归档日志文件

- 数据库优化
	- 表：建立分区表、重建索引

	- I/O：将数据、日志、索引放在不同I/O设备

	- 切分：横/纵向分割表

	- 硬件：升级CPU、内存、网络带宽等

	- 业务分离：OLTP与OLAP分离

	- 字段选取：where后的查询字段避免冗余


###3. 大数据


#####一、原生Hadoop


---

- Hadoop框架
	- 大数据概念及应用场景

	- Hadoop介绍

	- Hadoop组件

- HDFS组件
	- HDFS读取过程

	- HDFS基本命令：cat、chgrp、chmod、chown、cp、df、du、find、get、ls、lsr、mkdir、mv、put、rm、rmdir、rmr、tail、stat等

- Hive组件

	- Hive表结构与数据存储

	- Hive与RDBMS区别

	- Hive数据库与表

	- 基本HiveQL语法

	- 向Hive装载数据

- Sqoop组件
	
	- Sqoop工作原理

	- Sqoop数据流转

- Flume组件
	- Flume工作原理

	- Flume参数配置

	- 实时将系统日志文件导入HDFS

- HBase组件
	
	- HBase概念及应用场景

	- HBase与RDBMS联系与区别

	- HBase表结构与数据存储

#####二、CDH发行版本

---
未完待续...




