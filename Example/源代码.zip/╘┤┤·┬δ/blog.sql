/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 60011
Source Host           : localhost:3306
Source Database       : blog

Target Server Type    : MYSQL
Target Server Version : 60011
File Encoding         : 65001

Date: 2016-07-26 15:28:32
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for blog
-- ----------------------------
DROP TABLE IF EXISTS `blog`;
CREATE TABLE `blog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `blog_user_id` (`user_id`),
  CONSTRAINT `blog_user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of blog
-- ----------------------------
INSERT INTO `blog` VALUES ('1', '用业余时间读完114本英文原著成为大牛', '                                    因为词汇量是衡量我们英语核心能力的一个十分重要的指标，所以我们在挑选英语原著前要先对自己的词汇量进行一个简单的测试。词汇量测试的目的不在于数字，关键在于这个测试的结果能让自己对母语人士和非母语人士的英语水平进行比较。\r\n\r\n因此伍老师推荐了一个比较科学靠谱的测试词汇量的网站供我们测试            \r\n链接：http：//testyourvocab.com（亲测大约花3分钟就可以测试完毕）\r\n\r\n测试完之后，网站会出现一个我们目前所达到词汇量的参考值。\r\n\r\n而对于以上词汇测试的结果，老师是这么解读的：\r\n\r\n3千以下——很可能比不上美国三岁的小朋友\r\n\r\n1万词汇量以下——考试，运用词汇量比较困难\r\n\r\n（但要知道词汇量是一个动态的平衡，以上也只是一个参考。）\r\n\r\n        作者：吴超\r\n        \r\n        ', '2016-07-25 13:32:12', '1');
INSERT INTO `blog` VALUES ('2', '毕业不到2年时间月入过万的经历1', '在大学期间，我专业就是计算机，主修java，以前也是想以后简简单单的，能找到工作已经很幸运了。在大学毕业的那一年，我感到强烈的迷茫和无所适从，我什么技能都不会，包括我本专业的东西都是半吊子，根本无法跟上企业的节奏，除了自我提升，别无他法。在最后的几个月时间里，我看了很多java的入门基本视频，这对后来我去专业的培训埋下良好的基础。后来，实习的半年时间里，我没有真正意义上的去找工作，而是去了某个知名的培训机构专修技术，我觉得挺得上天的眷顾的，每次在最难抉择的时候，我总能找到一条柳暗花明的路，在那煎熬的几个月时间了，起早贪黑吸收知识，想想那时候也是蛮痛苦的，想想都觉得自己很可怜，唯一让我坚持下来就是信念了。出来社会，开始的时候找到跳板很重要，而那时候机构就是我的跳板，在学习的过程中方法也很重要，后来那边的老师邀请我回去分享学习心得，我也没有时间回去，我自己的学习体会就是，节奏！老师的节奏和自己的节奏，那个时候我学的很吃力，老是想着跟着老师节奏，可是越跟越吃力，穷则思变，后来我开始走自己的节奏，每天就做两个事，总结！总结自己的学习笔记和实践代码库，就这样我发现自己慢慢找到了感觉，很多东西懂思想，细节也没必要时时刻刻死记硬背。再后来，我也是我们那期唯一一个还未从培训机构毕业就拿到高薪offer的学员。这得益于决心，信念，方法和绝境带给我的激励。', '2016-07-25 13:33:46', '1');
INSERT INTO `blog` VALUES ('3', '毕业不到2年时间月入过万的经历2', '在第一家公司工作，我在那边呆了大概1年多时间吧，经历了公司从几个人到几百人再到几个人的过程，感触蛮多的。身边的小伙伴从不认识到好朋友一个一个的离开，也体会到一个公司的决策和管理，公司的文化对一个团队来说是多么的重要。我很珍惜在公司的工作经验，我也一直保持了工作中经验的总结笔记和代码案例库的积累，简单的事情重复做，总有一天回过头，你会发现自己所有的努力只是让你离追求更接近一点。说句自私的话，一般公司刚开始的时候总是给你大饼，这个时候保持内心的判别就可以了，但千万别安逸，忘了给自己增值。一个不懂给自己增值的人，总有天会被浪潮给淘汰掉的。每天工作结束后，该记录的记录，总结的总结，积累的积累，即使是懂得东西，看看别人的思想，也会有更开拓的视野。这个阶段切记积累，为以后进阶打基础。\r\n\r\n文／维c流（简书作者）', '2016-07-25 13:34:35', '1');
INSERT INTO `blog` VALUES ('4', '毕业不到2年时间月入过万的经历3', '第二年，我离开的第一家公司。经朋友介绍去了一家待遇更好一点的公司，这一年的时间我前后经历了两家公司，遇到了不同技术领域的佼佼者，在他们身上，我学习了很多优秀的习惯，我有机会把他们好的方面吸收过来，包括技术、做事、严谨等等，这永远比你在一家公司，作为一只井底之蛙进步来的有效和快捷。所有说，毕业的开始三年，到底应不应该跳槽，这就见仁见智了，最根本还是自己。但不是那种盲目跳槽然后追求高薪，这会让你打击很大，而已很招公司讨厌。在一家公司待着，能让你发挥价值，有归属感，像家人一样一起成长，那你应该和公司共进退。但一般的创业公司普遍存在的现象是，兔死狗烹，你去到这样的公司，作为一块砖头，利用完了就可以走人的，那你要时刻提醒自己，打造自己的价值和竞争力，同时学习公司行的通的和行不通的，为以后自己有机会带团队打基础。这个阶段，我觉得人应该多出去走走，经历不同人不同事，这会让你经历和经验得到质的提升\r\n\r\n文／维c流（简书作者）\r\n', '2016-07-25 13:35:12', '1');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(16) NOT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1', 'admin', 'admin', '2016-07-07 12:18:10');
INSERT INTO `user` VALUES ('2', 'admin2', 'admin', '2016-07-26 10:53:15');
INSERT INTO `user` VALUES ('3', 'admin2', 'admin', '2016-07-26 15:25:21');
INSERT INTO `user` VALUES ('4', 'admin3', 'admin', '2016-07-26 15:25:37');
