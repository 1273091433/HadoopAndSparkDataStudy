package com.hithinksoft.controller;

import com.hithinksoft.model.Blog;
import com.jfinal.core.Controller;

import java.util.List;

public class BlogController extends Controller {
	
	public void index() {
		renderJsp("index.jsp");
	}
	
	public void blogs() {
		//查询所有的博客
		List<Blog> blogs = Blog.blogRepository.find("select * from blog");
		//将查询到的博客保存进 request作用域中，这样就可以在前端页面中获取到这些博客
		setAttr("blogs", blogs);
		renderJsp("blogs/blogs.jsp");
	}

	public void blog() {
		Integer blogId = getParaToInt(0);
		Blog blog = Blog.blogRepository.findById(blogId);
		setAttr("blog", blog);
		renderJsp("blogs/blog.jsp");
	}

	public void publish() {
		renderJsp("blogs/publish.jsp");
	}

	public void publishBlog() {
		Integer userId = getParaToInt(0);
		Blog blog = getModel(Blog.class);
		blog.set("user_id", userId);
		/**
		 *
		 */
		blog.save();
		redirect("/blogs/blogs");
	}

	public void update() {
		Integer blogId = getParaToInt(0);
		Blog blog = Blog.blogRepository.findById(blogId);
		setAttr("blog", blog);
		renderJsp("blogs/update.jsp");
	}

	public void updateBlog() {
		Integer blogId = getParaToInt(0);
		Blog blog = getModel(Blog.class);
		blog.set("id", blogId);
		blog.update();
		redirect("/blogs/blogs");
	}

	public void delete() {
		Integer blogId = getParaToInt(0);
		Blog.blogRepository.deleteById(blogId);
		redirect("/blogs/blogs");
	}
}
