package com.hithinksoft.controller;

import com.hithinksoft.model.User;
import com.jfinal.core.Controller;

public class UserController extends Controller {
	
	public void register() {

		renderJsp("users/register.jsp");
	}

	public void regUser() {
		User user = getModel(User.class);
		String username = user.get("username");
		String password = user.get("password");
		System.out.println(username +"==="+password);

		//持久化user对象到数据库中
		user.save();
		//注册成功跳转到登录页面
		renderJsp("users/login.jsp");
	}
	
	public void login() {
		renderJsp("users/login.jsp");
	}

	public void loginUser() {
		User user = getModel(User.class);
		String username = user.getStr("username");
		String password = user.getStr("password");
		user = user.validate(username, password);
		if (user != null) {
			setSessionAttr("user", user);
			redirect("/blogs/blogs");
		} else {
			redirect("/users/login");
		}
	}

	public void logout() {
		getSession().removeAttribute("user");
		redirect("/blogs/blogs");
	}
}
