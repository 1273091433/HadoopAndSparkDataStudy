package com.hithinksoft.config;

import com.hithinksoft.controller.BlogController;
import com.hithinksoft.controller.HelloController;
import com.hithinksoft.controller.UserController;
import com.hithinksoft.model.Blog;
import com.hithinksoft.model.User;
import com.jfinal.config.Constants;
import com.jfinal.config.Handlers;
import com.jfinal.config.Interceptors;
import com.jfinal.config.JFinalConfig;
import com.jfinal.config.Plugins;
import com.jfinal.config.Routes;
import com.jfinal.kit.PropKit;
import com.jfinal.plugin.activerecord.ActiveRecordPlugin;
import com.jfinal.plugin.c3p0.C3p0Plugin;
import com.jfinal.render.ViewType;

public class MyConfig extends JFinalConfig {
	private static String VIEWURL = "/WEB-INF/pages/";

	@Override
	public void configConstant(Constants constants) {
		/*开发模式常量devMode设置为true，这样程序运行时会打印一些调试信息等*/
		constants.setDevMode(true);

		/*设置编码格式为UTF-8*/
		constants.setEncoding("UTF-8");

		/**
		 * 设置视图类型为JSP
		 * 如果页面中使用了FreeMarker，则应该写成：
		 * constants.setViewType(ViewType.FREE_MARKER);
		 * */
		constants.setViewType(ViewType.JSP);
	}

	@Override
	public void configRoute(Routes routes) {
		routes.add("/", HelloController.class);
		/**
		 * 当在浏览器中访问 “http://localhost:8080/blog/users/login”时，
		 * 会映射到 UserController.java中的 login()方法。
		 * 第三个参数 MyConfig.VIEWURL是个常量，它的值是： "/WEB-INF/pages/"，
		 * 它表示Controller返回的视图的相对路径，
		 * 它的作用是：当调用了 UserController中的 login()方法的renderJsp("users/login.jsp")语句时，
		 * 代码会将“/WEB-INF/pages/”与renderJsp中的参数 “users/login.jsp”拼接起来得到的
		 * 路径作为即将打开的页面的路径。也就是说当在浏览器地址栏中输入了
		 * “http://localhost:8080/blog/users/login”之后，浏览器会访问到
		 * “/WEB-INF/pages/users/login.jsp”这个页面
		 */
		routes.add("/users", UserController.class, MyConfig.VIEWURL);
		routes.add("/blogs", BlogController.class, MyConfig.VIEWURL);
	}

	@Override
	public void configPlugin(Plugins plugins) {
		/**
		 * 加载db.txt文件，db.txt是自己创建的文件，里面填写了一些连接数据库时必要的参数
		 * 相似的也可以将其他一些配置信息（如configConstant()方法中的的devMode、视图类型
		 * 等等）放到一个文件中，然后通过这种方法来获取其中的参数。
		 * */
		PropKit.use("db.txt");

		/*从db.txt文件中获取以下四个属性值作为C3p0Plugin的参数来创建一个C3p0Plugin对象*/
		C3p0Plugin cp = new C3p0Plugin(PropKit.get("jdbcUrl"),
				PropKit.get("user"),
				PropKit.get("password").trim(),
				PropKit.get("driverClass"));

		/*将C3p0Plugin这个插件初始化完成后添加到工程项目中*/
		plugins.add(cp);

		/**
		 * C3p0Plugin是数据源，通过这个数据源创建一个ActiveRecordPlugin对象
		 * ActiveRecordPlugin是ActiveRecord的支持插件，ActiveRecord中定义了：
		 * addMapping(String tableName, Class<? extends Model> modelClass)方法
		 * 该方法建立了数据库表名到Model的映射关系
		 */
		ActiveRecordPlugin arp = new ActiveRecordPlugin(cp);
		plugins.add(arp);
		arp.addMapping("user", User.class);
		arp.addMapping("blog", Blog.class);
	}

	@Override
	public void configInterceptor(Interceptors interceptors) {
	}

	@Override
	public void configHandler(Handlers handlers) {
	}
}
