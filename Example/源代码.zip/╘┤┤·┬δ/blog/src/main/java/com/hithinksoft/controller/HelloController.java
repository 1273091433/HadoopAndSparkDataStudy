package com.hithinksoft.controller;

import com.jfinal.core.Controller;

/**
 * @author WuChao on 2016/7/25.
 */
public class HelloController extends Controller {

    public void index() {
        renderJsp("index.jsp");
    }
}
