package com.hithinksoft.model;

import com.jfinal.plugin.activerecord.Model;

import java.util.List;

public class User extends Model<User> {

	private static final long serialVersionUID = 1L;
	public static User userRepository = new User();
	
	public User() {
		
	}
	
	public static User getUser(Integer userId) {
		return (User) User.userRepository.find("select * from u where u.id = ?", userId);
	}
	
	public List<Blog> getBlogs() {
		return Blog.blogRepository.find("select * from blog b where b.user_id = ?", get("id"));

	}
	
	public User validate(String username, String password) {
		/**
		 * select * 不能写成 select u
		 */
		List<User> users = this.userRepository.find("select * from user u where u.username = ? and u.password = ?", username, password);
		return (users != null && users.size() > 0) ? users.get(0) : null;
	}
}
