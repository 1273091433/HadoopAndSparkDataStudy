package com.hithinksoft.model;

import com.jfinal.plugin.activerecord.Model;

public class Blog extends Model<Blog> {

	private static final long serialVersionUID = 1L;
	public static Blog blogRepository = new Blog();
	
	public User getUser() {
		return User.userRepository.findById(get("user_id"));
	}
	
}
